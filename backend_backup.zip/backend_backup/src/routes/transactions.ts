import { Express, Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { db } from '../db';
import { AppError, AuthRequest, authMiddleware } from '../middleware';

// ============ TRANSACTION ROUTES ============
export const setupTransactionRoutes = (app: Express) => {
  // Create new order
  app.post('/transactions', authMiddleware, async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const { items } = z.object({
        items: z.array(
          z.object({
            book_id: z.string().min(1, 'Book ID tidak boleh kosong'),
            quantity: z.number().min(1, 'Quantity minimal 1')
          })
        ).min(1, 'Minimal 1 item dalam order')
      }).parse(req.body);

      // Validasi stock untuk semua items
      const bookDetails = [];
      for (const item of items) {
        const book = await db.books.findFirst({
          where: { id: item.book_id, deleted_at: null }
        });

        if (!book) {
          throw new AppError(`Buku dengan ID ${item.book_id} tidak ditemukan`, 404);
        }

        if (book.stock_quantity < item.quantity) {
          throw new AppError(
            `Stok ${book.title} tidak cukup. Tersedia: ${book.stock_quantity}, diminta: ${item.quantity}`,
            400
          );
        }

        bookDetails.push({ ...book, requestedQuantity: item.quantity });
      }

      // Create order
      const order = await db.orders.create({
        data: {
          user_id: req.userId!,
          order_items: {
            create: items.map(item => ({
              book_id: item.book_id,
              quantity: item.quantity
            }))
          }
        },
        include: {
          order_items: {
            include: { book: { include: { genre: true } } }
          }
        }
      });

      // Update stock untuk semua items
      for (const item of items) {
        await db.books.update({
          where: { id: item.book_id },
          data: { stock_quantity: { decrement: item.quantity } }
        });
      }

      // Calculate total
      const total = order.order_items.reduce(
        (sum: number, item: any) => sum + Number(item.book.price) * item.quantity,
        0
      );

      res.status(201).json({
        success: true,
        data: { ...order, total }
      });
    } catch (error) {
      next(error);
    }
  });

  // Get all orders for logged-in user
  app.get('/transactions', authMiddleware, async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const orders = await db.orders.findMany({
        where: { user_id: req.userId },
        include: {
          order_items: {
            include: { book: { include: { genre: true } } }
          }
        },
        orderBy: { created_at: 'desc' }
      });

      const ordersWithTotal = orders.map((order: any) => ({
        ...order,
        total: order.order_items.reduce(
          (sum: number, item: any) => sum + Number(item.book.price) * item.quantity,
          0
        )
      }));

      res.json({ success: true, data: ordersWithTotal });
    } catch (error) {
      next(error);
    }
  });

  // Get specific order detail
  app.get(
    '/transactions/:transaction_id',
    authMiddleware,
    async (req: AuthRequest, res: Response, next: NextFunction) => {
      try {
        const { transaction_id } = req.params;

        const order = await db.orders.findFirst({
          where: { id: transaction_id, user_id: req.userId },
          include: {
            order_items: {
              include: { book: { include: { genre: true } } }
            }
          }
        });

        if (!order) {
          throw new AppError('Order tidak ditemukan atau bukan milik Anda', 404);
        }

        const total = order.order_items.reduce(
          (sum: number, item: any) => sum + Number(item.book.price) * item.quantity,
          0
        );

        res.json({ success: true, data: { ...order, total } });
      } catch (error) {
        next(error);
      }
    }
  );

  // Get sales statistics
  app.get(
    '/transactions/statistics',
    authMiddleware,
    async (req: Request, res: Response, next: NextFunction) => {
      try {
        const orders = await db.orders.findMany({
          include: {
            order_items: {
              include: { book: { include: { genre: true } } }
            }
          }
        });

        if (orders.length === 0) {
          return res.json({
            success: true,
            data: {
              totalTransactions: 0,
              avgTransaction: 0,
              mostPopularGenre: null,
              leastPopularGenre: null
            }
          });
        }

        // Calculate total transactions
        const totalTransactions = orders.length;

        // Calculate total amount and average
        const totalAmount = orders.reduce((sum: number, order: any) =>
          sum + order.order_items.reduce(
            (s: number, item: any) => s + Number(item.book.price) * item.quantity,
            0
          ),
          0
        );
        const avgTransaction = totalAmount / totalTransactions;

        // Count books by genre
        const genreCounts: { [key: string]: number } = {};
        orders.forEach((order: any) => {
          order.order_items.forEach((item: any) => {
            const genreName = item.book.genre.name;
            genreCounts[genreName] = (genreCounts[genreName] || 0) + 1;
          });
        });

        // Sort genres by count
        const sorted = Object.entries(genreCounts).sort(
          (a: [string, number], b: [string, number]) => b[1] - a[1]
        );

        const mostPopular = sorted[0]?.[0] || null;
        const leastPopular = sorted[sorted.length - 1]?.[0] || null;

        res.json({
          success: true,
          data: {
            totalTransactions,
            avgTransaction: parseFloat(avgTransaction.toFixed(2)),
            mostPopularGenre: mostPopular,
            leastPopularGenre: leastPopular,
            genreBreakdown: Object.fromEntries(sorted)
          }
        });
      } catch (error) {
        next(error);
      }
    }
  );
};