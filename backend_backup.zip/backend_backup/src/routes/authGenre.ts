import { Express, Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from '../db';
import { AppError, AuthRequest, authMiddleware } from '../middleware';

export const setupAuthRoutes = (app: Express) => {
  app.post('/auth/register', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, password, username } = z.object({
        email: z.string().email(),
        password: z.string().min(6),
        username: z.string().optional()
      }).parse(req.body);

      const existing = await db.users.findUnique({ where: { email } });
      if (existing) throw new AppError('Email sudah ada', 400);

      const user = await db.users.create({
        data: {
          email,
          password: await bcrypt.hash(password, 10),
          username: username || null
        },
        select: { id: true, email: true, username: true }
      });

      res.status(201).json({ success: true, data: user });
    } catch (error) {
      next(error);
    }
  });

  app.post('/auth/login', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, password } = z.object({
        email: z.string().email(),
        password: z.string()
      }).parse(req.body);

      const user = await db.users.findUnique({ where: { email } });
      if (!user || !(await bcrypt.compare(password, user.password))) {
        throw new AppError('Email/password salah', 401);
      }

      const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET!, { expiresIn: '7d' });
      res.json({ success: true, data: { token, user: { id: user.id, email: user.email } } });
    } catch (error) {
      next(error);
    }
  });

  app.get('/auth/me', authMiddleware, async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const user = await db.users.findUnique({
        where: { id: req.userId },
        select: { id: true, email: true, username: true }
      });
      if (!user) throw new AppError('User tidak ada', 404);
      res.json({ success: true, data: user });
    } catch (error) {
      next(error);
    }
  });
};

export const setupGenreRoutes = (app: Express) => {
  app.post('/genre', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { name } = z.object({ name: z.string() }).parse(req.body);
      const genre = await db.genres.create({ data: { name } });
      res.status(201).json({ success: true, data: genre });
    } catch (error) {
      next(error);
    }
  });

  app.get('/genre', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const genres = await db.genres.findMany({
        where: { deleted_at: null },
        include: { _count: { select: { books: true } } }
      });
      res.json({ success: true, data: genres });
    } catch (error) {
      next(error);
    }
  });

  app.get('/genre/:genre_id', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const genre = await db.genres.findFirst({
        where: { id: req.params.genre_id, deleted_at: null }
      });
      if (!genre) throw new AppError('Genre tidak ada', 404);
      res.json({ success: true, data: genre });
    } catch (error) {
      next(error);
    }
  });

  app.patch('/genre/:genre_id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { name } = z.object({ name: z.string() }).parse(req.body);
      const genre = await db.genres.update({
        where: { id: req.params.genre_id },
        data: { name }
      });
      res.json({ success: true, data: genre });
    } catch (error) {
      next(error);
    }
  });

  app.delete('/genre/:genre_id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
      await db.genres.update({
        where: { id: req.params.genre_id },
        data: { deleted_at: new Date() }
      });
      res.json({ success: true, message: 'Genre dihapus' });
    } catch (error) {
      next(error);
    }
  });
};

export const setupBookRoutes = (app: Express) => {
  app.post('/books', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
      const data = z.object({
        title: z.string(),
        writer: z.string(),
        publisher: z.string(),
        publication_year: z.number(),
        description: z.string().optional(),
        price: z.number(),
        stock_quantity: z.number(),
        genre_id: z.string()
      }).parse(req.body);

      const book = await db.books.create({
        data,
        include: { genre: true }
      });
      res.status(201).json({ success: true, data: book });
    } catch (error) {
      next(error);
    }
  });

  app.get('/books', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = '1', limit = '10', search } = req.query;
      const p = parseInt(page as string);
      const l = parseInt(limit as string);

      const where: any = { deleted_at: null };
      if (search) {
        where.OR = [
          { title: { contains: search as string, mode: 'insensitive' } },
          { writer: { contains: search as string, mode: 'insensitive' } }
        ];
      }

      const [books, total] = await Promise.all([
        db.books.findMany({
          where,
          skip: (p - 1) * l,
          take: l,
          include: { genre: true },
          orderBy: { created_at: 'desc' }
        }),
        db.books.count({ where })
      ]);

      res.json({
        success: true,
        data: books,
        pagination: { page: p, limit: l, total, totalPages: Math.ceil(total / l) }
      });
    } catch (error) {
      next(error);
    }
  });

  app.get('/books/genre/:genre_id', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = '1', limit = '10' } = req.query;
      const p = parseInt(page as string);
      const l = parseInt(limit as string);

      const where = { genre_id: req.params.genre_id, deleted_at: null };

      const [books, total] = await Promise.all([
        db.books.findMany({
          where,
          skip: (p - 1) * l,
          take: l,
          include: { genre: true }
        }),
        db.books.count({ where })
      ]);

      res.json({
        success: true,
        data: books,
        pagination: { page: p, limit: l, total, totalPages: Math.ceil(total / l) }
      });
    } catch (error) {
      next(error);
    }
  });

  app.get('/books/:book_id', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const book = await db.books.findFirst({
        where: { id: req.params.book_id, deleted_at: null },
        include: { genre: true }
      });
      if (!book) throw new AppError('Buku tidak ada', 404);
      res.json({ success: true, data: book });
    } catch (error) {
      next(error);
    }
  });

  app.patch('/books/:book_id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
      const data = z.object({
        title: z.string().optional(),
        writer: z.string().optional(),
        publisher: z.string().optional(),
        publication_year: z.number().optional(),
        description: z.string().optional(),
        price: z.number().optional(),
        stock_quantity: z.number().optional(),
        genre_id: z.string().optional()
      }).parse(req.body);

      const book = await db.books.update({
        where: { id: req.params.book_id },
        data,
        include: { genre: true }
      });
      res.json({ success: true, data: book });
    } catch (error) {
      next(error);
    }
  });

  app.delete('/books/:book_id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
      await db.books.update({
        where: { id: req.params.book_id },
        data: { deleted_at: new Date() }
      });
      res.json({ success: true, message: 'Buku dihapus' });
    } catch (error) {
      next(error);
    }
  });
};